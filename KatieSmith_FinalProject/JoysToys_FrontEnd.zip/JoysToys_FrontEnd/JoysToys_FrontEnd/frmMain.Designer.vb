﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.btnOrderInv = New System.Windows.Forms.Button()
        Me.btnCustomerOrder = New System.Windows.Forms.Button()
        Me.btnRequests = New System.Windows.Forms.Button()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.lblSubHeader = New System.Windows.Forms.Label()
        Me.lblSelectWindow = New System.Windows.Forms.Label()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.CustomerOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.mnuMain.SuspendLayout()
        Me.pnlMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOrderInv
        '
        Me.btnOrderInv.BackColor = System.Drawing.Color.LightGray
        Me.btnOrderInv.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrderInv.ForeColor = System.Drawing.Color.Black
        Me.btnOrderInv.Location = New System.Drawing.Point(8, 3)
        Me.btnOrderInv.Name = "btnOrderInv"
        Me.btnOrderInv.Size = New System.Drawing.Size(274, 234)
        Me.btnOrderInv.TabIndex = 0
        Me.btnOrderInv.Text = "Order New Inventory"
        Me.ToolTip1.SetToolTip(Me.btnOrderInv, "Order New Inventory Items")
        Me.btnOrderInv.UseVisualStyleBackColor = False
        '
        'btnCustomerOrder
        '
        Me.btnCustomerOrder.BackColor = System.Drawing.Color.LightGray
        Me.btnCustomerOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustomerOrder.ForeColor = System.Drawing.Color.Black
        Me.btnCustomerOrder.Location = New System.Drawing.Point(286, 3)
        Me.btnCustomerOrder.Name = "btnCustomerOrder"
        Me.btnCustomerOrder.Size = New System.Drawing.Size(274, 234)
        Me.btnCustomerOrder.TabIndex = 1
        Me.btnCustomerOrder.Text = "Customer Order"
        Me.ToolTip1.SetToolTip(Me.btnCustomerOrder, "Process a Customer's Order")
        Me.btnCustomerOrder.UseVisualStyleBackColor = False
        '
        'btnRequests
        '
        Me.btnRequests.BackColor = System.Drawing.Color.LightGray
        Me.btnRequests.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRequests.ForeColor = System.Drawing.Color.Black
        Me.btnRequests.Location = New System.Drawing.Point(563, 3)
        Me.btnRequests.Name = "btnRequests"
        Me.btnRequests.Size = New System.Drawing.Size(274, 234)
        Me.btnRequests.TabIndex = 2
        Me.btnRequests.Text = "View Requests"
        Me.ToolTip1.SetToolTip(Me.btnRequests, "Inventory Requests From Website")
        Me.btnRequests.UseVisualStyleBackColor = False
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.Red
        Me.lblHeader.Location = New System.Drawing.Point(165, 24)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(536, 55)
        Me.lblHeader.TabIndex = 4
        Me.lblHeader.Text = "Welcome to Joy's Toys"
        '
        'lblSubHeader
        '
        Me.lblSubHeader.AutoSize = True
        Me.lblSubHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubHeader.Location = New System.Drawing.Point(263, 79)
        Me.lblSubHeader.Name = "lblSubHeader"
        Me.lblSubHeader.Size = New System.Drawing.Size(340, 24)
        Me.lblSubHeader.TabIndex = 5
        Me.lblSubHeader.Text = "Family owned and operated since 1945"
        '
        'lblSelectWindow
        '
        Me.lblSelectWindow.AutoSize = True
        Me.lblSelectWindow.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectWindow.Location = New System.Drawing.Point(336, 170)
        Me.lblSelectWindow.Name = "lblSelectWindow"
        Me.lblSelectWindow.Size = New System.Drawing.Size(194, 29)
        Me.lblSelectWindow.TabIndex = 6
        Me.lblSelectWindow.Text = "Select Window:"
        '
        'mnuMain
        '
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerOrderToolStripMenuItem})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(867, 24)
        Me.mnuMain.TabIndex = 7
        Me.mnuMain.Text = "MenuStrip1"
        '
        'CustomerOrderToolStripMenuItem
        '
        Me.CustomerOrderToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.CustomerOrderToolStripMenuItem.Name = "CustomerOrderToolStripMenuItem"
        Me.CustomerOrderToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.CustomerOrderToolStripMenuItem.Text = "&File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(93, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'pnlMain
        '
        Me.pnlMain.BackColor = System.Drawing.Color.Red
        Me.pnlMain.Controls.Add(Me.btnRequests)
        Me.pnlMain.Controls.Add(Me.btnOrderInv)
        Me.pnlMain.Controls.Add(Me.btnCustomerOrder)
        Me.pnlMain.Location = New System.Drawing.Point(12, 223)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(843, 240)
        Me.pnlMain.TabIndex = 8
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(201, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(867, 475)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.lblSelectWindow)
        Me.Controls.Add(Me.lblSubHeader)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.mnuMain)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuMain
        Me.Name = "frmMain"
        Me.Text = "Joy's Toys - Main"
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.pnlMain.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnOrderInv As Button
    Friend WithEvents btnCustomerOrder As Button
    Friend WithEvents btnRequests As Button
    Friend WithEvents lblHeader As Label
    Friend WithEvents lblSubHeader As Label
    Friend WithEvents lblSelectWindow As Label
    Friend WithEvents mnuMain As MenuStrip
    Friend WithEvents CustomerOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents pnlMain As Panel
End Class
