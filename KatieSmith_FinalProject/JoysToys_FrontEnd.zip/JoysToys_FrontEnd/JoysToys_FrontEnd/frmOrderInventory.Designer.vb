﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrderInventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOrderInventory))
        Me.lblSubHeader = New System.Windows.Forms.Label()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.lblReorderInventoryHeader = New System.Windows.Forms.Label()
        Me.lblOrderInventory = New System.Windows.Forms.Label()
        Me.btnReorderInventory = New System.Windows.Forms.Button()
        Me.txtReorderQuantity = New System.Windows.Forms.TextBox()
        Me.lblReorderQuantity = New System.Windows.Forms.Label()
        Me.mnuReorderInventory = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomepageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewCustomerOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewCustomerRequestsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnReturnToMain = New System.Windows.Forms.Button()
        Me.dgvOrderInventory = New System.Windows.Forms.DataGridView()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnPrintInventory = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.lblNameHeader = New System.Windows.Forms.Label()
        Me.lblNameOutput = New System.Windows.Forms.Label()
        Me.lblProductQty = New System.Windows.Forms.Label()
        Me.lblProductQtyOutput = New System.Windows.Forms.Label()
        Me.lblProductPrice = New System.Windows.Forms.Label()
        Me.lblProductPriceOutput = New System.Windows.Forms.Label()
        Me.lblReorderSuccess = New System.Windows.Forms.Label()
        Me.lblSelectedHeader = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.pnlPlaceReorder = New System.Windows.Forms.Panel()
        Me.pnlReturnToMainMenu = New System.Windows.Forms.Panel()
        Me.pnlPrintInventory = New System.Windows.Forms.Panel()
        Me.pnlRefresh = New System.Windows.Forms.Panel()
        Me.mnuReorderInventory.SuspendLayout()
        CType(Me.dgvOrderInventory, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.pnlPlaceReorder.SuspendLayout()
        Me.pnlReturnToMainMenu.SuspendLayout()
        Me.pnlPrintInventory.SuspendLayout()
        Me.pnlRefresh.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblSubHeader
        '
        Me.lblSubHeader.AutoSize = True
        Me.lblSubHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubHeader.Location = New System.Drawing.Point(417, 64)
        Me.lblSubHeader.Name = "lblSubHeader"
        Me.lblSubHeader.Size = New System.Drawing.Size(340, 24)
        Me.lblSubHeader.TabIndex = 10
        Me.lblSubHeader.Text = "Family owned and operated since 1945"
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.Red
        Me.lblHeader.Location = New System.Drawing.Point(319, 9)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(536, 55)
        Me.lblHeader.TabIndex = 9
        Me.lblHeader.Text = "Welcome to Joy's Toys"
        '
        'lblReorderInventoryHeader
        '
        Me.lblReorderInventoryHeader.AutoSize = True
        Me.lblReorderInventoryHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReorderInventoryHeader.Location = New System.Drawing.Point(477, 151)
        Me.lblReorderInventoryHeader.Name = "lblReorderInventoryHeader"
        Me.lblReorderInventoryHeader.Size = New System.Drawing.Size(221, 29)
        Me.lblReorderInventoryHeader.TabIndex = 8
        Me.lblReorderInventoryHeader.Text = "Reorder Inventory"
        '
        'lblOrderInventory
        '
        Me.lblOrderInventory.AutoSize = True
        Me.lblOrderInventory.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrderInventory.Location = New System.Drawing.Point(99, 222)
        Me.lblOrderInventory.Name = "lblOrderInventory"
        Me.lblOrderInventory.Size = New System.Drawing.Size(216, 20)
        Me.lblOrderInventory.TabIndex = 12
        Me.lblOrderInventory.Text = "Click Row of Item to Reorder:"
        '
        'btnReorderInventory
        '
        Me.btnReorderInventory.BackColor = System.Drawing.Color.LightGray
        Me.btnReorderInventory.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReorderInventory.ForeColor = System.Drawing.Color.Black
        Me.btnReorderInventory.Location = New System.Drawing.Point(3, 3)
        Me.btnReorderInventory.Name = "btnReorderInventory"
        Me.btnReorderInventory.Size = New System.Drawing.Size(266, 68)
        Me.btnReorderInventory.TabIndex = 13
        Me.btnReorderInventory.Text = "Place Reorder"
        Me.ToolTip1.SetToolTip(Me.btnReorderInventory, "Click to Place Order")
        Me.btnReorderInventory.UseVisualStyleBackColor = False
        '
        'txtReorderQuantity
        '
        Me.txtReorderQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReorderQuantity.Location = New System.Drawing.Point(1000, 261)
        Me.txtReorderQuantity.Name = "txtReorderQuantity"
        Me.txtReorderQuantity.Size = New System.Drawing.Size(57, 26)
        Me.txtReorderQuantity.TabIndex = 14
        Me.txtReorderQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ToolTip1.SetToolTip(Me.txtReorderQuantity, "Enter Reorder Quantity")
        '
        'lblReorderQuantity
        '
        Me.lblReorderQuantity.AutoSize = True
        Me.lblReorderQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReorderQuantity.Location = New System.Drawing.Point(962, 222)
        Me.lblReorderQuantity.Name = "lblReorderQuantity"
        Me.lblReorderQuantity.Size = New System.Drawing.Size(134, 20)
        Me.lblReorderQuantity.TabIndex = 15
        Me.lblReorderQuantity.Text = "Reorder Quantity:"
        '
        'mnuReorderInventory
        '
        Me.mnuReorderInventory.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.mnuReorderInventory.Location = New System.Drawing.Point(0, 0)
        Me.mnuReorderInventory.Name = "mnuReorderInventory"
        Me.mnuReorderInventory.Size = New System.Drawing.Size(1175, 24)
        Me.mnuReorderInventory.TabIndex = 17
        Me.mnuReorderInventory.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomepageToolStripMenuItem, Me.NewCustomerOrderToolStripMenuItem, Me.ViewCustomerRequestsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'HomepageToolStripMenuItem
        '
        Me.HomepageToolStripMenuItem.Name = "HomepageToolStripMenuItem"
        Me.HomepageToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.HomepageToolStripMenuItem.Text = "&Main Menu"
        '
        'NewCustomerOrderToolStripMenuItem
        '
        Me.NewCustomerOrderToolStripMenuItem.Name = "NewCustomerOrderToolStripMenuItem"
        Me.NewCustomerOrderToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.NewCustomerOrderToolStripMenuItem.Text = "New Customer &Order"
        '
        'ViewCustomerRequestsToolStripMenuItem
        '
        Me.ViewCustomerRequestsToolStripMenuItem.Name = "ViewCustomerRequestsToolStripMenuItem"
        Me.ViewCustomerRequestsToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.ViewCustomerRequestsToolStripMenuItem.Text = "View Customer &Requests"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'btnReturnToMain
        '
        Me.btnReturnToMain.BackColor = System.Drawing.Color.LightGray
        Me.btnReturnToMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturnToMain.ForeColor = System.Drawing.Color.Black
        Me.btnReturnToMain.Location = New System.Drawing.Point(4, 3)
        Me.btnReturnToMain.Name = "btnReturnToMain"
        Me.btnReturnToMain.Size = New System.Drawing.Size(266, 68)
        Me.btnReturnToMain.TabIndex = 18
        Me.btnReturnToMain.Text = "Return to Main Menu"
        Me.ToolTip1.SetToolTip(Me.btnReturnToMain, "Go Back to Main Menu Page")
        Me.btnReturnToMain.UseVisualStyleBackColor = False
        '
        'dgvOrderInventory
        '
        Me.dgvOrderInventory.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvOrderInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvOrderInventory.Location = New System.Drawing.Point(12, 245)
        Me.dgvOrderInventory.Name = "dgvOrderInventory"
        Me.dgvOrderInventory.Size = New System.Drawing.Size(419, 428)
        Me.dgvOrderInventory.TabIndex = 19
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.LightGray
        Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefresh.ForeColor = System.Drawing.Color.Black
        Me.btnRefresh.Location = New System.Drawing.Point(3, 4)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(266, 68)
        Me.btnRefresh.TabIndex = 20
        Me.btnRefresh.Text = "Refresh"
        Me.ToolTip1.SetToolTip(Me.btnRefresh, "Refresh Inventory List")
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'btnPrintInventory
        '
        Me.btnPrintInventory.BackColor = System.Drawing.Color.LightGray
        Me.btnPrintInventory.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrintInventory.ForeColor = System.Drawing.Color.Black
        Me.btnPrintInventory.Location = New System.Drawing.Point(4, 4)
        Me.btnPrintInventory.Name = "btnPrintInventory"
        Me.btnPrintInventory.Size = New System.Drawing.Size(266, 68)
        Me.btnPrintInventory.TabIndex = 30
        Me.btnPrintInventory.Text = "Print Inventory"
        Me.ToolTip1.SetToolTip(Me.btnPrintInventory, "Print Inventory List")
        Me.btnPrintInventory.UseVisualStyleBackColor = False
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'lblNameHeader
        '
        Me.lblNameHeader.AutoSize = True
        Me.lblNameHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameHeader.Location = New System.Drawing.Point(7, 51)
        Me.lblNameHeader.Name = "lblNameHeader"
        Me.lblNameHeader.Size = New System.Drawing.Size(114, 20)
        Me.lblNameHeader.TabIndex = 21
        Me.lblNameHeader.Text = "Product Name:"
        '
        'lblNameOutput
        '
        Me.lblNameOutput.AutoSize = True
        Me.lblNameOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameOutput.Location = New System.Drawing.Point(127, 51)
        Me.lblNameOutput.Name = "lblNameOutput"
        Me.lblNameOutput.Size = New System.Drawing.Size(63, 20)
        Me.lblNameOutput.TabIndex = 22
        Me.lblNameOutput.Text = "Label2"
        '
        'lblProductQty
        '
        Me.lblProductQty.AutoSize = True
        Me.lblProductQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductQty.Location = New System.Drawing.Point(7, 111)
        Me.lblProductQty.Name = "lblProductQty"
        Me.lblProductQty.Size = New System.Drawing.Size(94, 20)
        Me.lblProductQty.TabIndex = 23
        Me.lblProductQty.Text = "Current Qty:"
        '
        'lblProductQtyOutput
        '
        Me.lblProductQtyOutput.AutoSize = True
        Me.lblProductQtyOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductQtyOutput.Location = New System.Drawing.Point(127, 111)
        Me.lblProductQtyOutput.Name = "lblProductQtyOutput"
        Me.lblProductQtyOutput.Size = New System.Drawing.Size(16, 20)
        Me.lblProductQtyOutput.TabIndex = 24
        Me.lblProductQtyOutput.Text = "x"
        '
        'lblProductPrice
        '
        Me.lblProductPrice.AutoSize = True
        Me.lblProductPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductPrice.Location = New System.Drawing.Point(7, 171)
        Me.lblProductPrice.Name = "lblProductPrice"
        Me.lblProductPrice.Size = New System.Drawing.Size(107, 20)
        Me.lblProductPrice.TabIndex = 25
        Me.lblProductPrice.Text = "Product Price:"
        '
        'lblProductPriceOutput
        '
        Me.lblProductPriceOutput.AutoSize = True
        Me.lblProductPriceOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductPriceOutput.Location = New System.Drawing.Point(127, 171)
        Me.lblProductPriceOutput.Name = "lblProductPriceOutput"
        Me.lblProductPriceOutput.Size = New System.Drawing.Size(18, 20)
        Me.lblProductPriceOutput.TabIndex = 26
        Me.lblProductPriceOutput.Text = "1"
        '
        'lblReorderSuccess
        '
        Me.lblReorderSuccess.AutoSize = True
        Me.lblReorderSuccess.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReorderSuccess.ForeColor = System.Drawing.Color.Red
        Me.lblReorderSuccess.Location = New System.Drawing.Point(526, 563)
        Me.lblReorderSuccess.Name = "lblReorderSuccess"
        Me.lblReorderSuccess.Size = New System.Drawing.Size(291, 58)
        Me.lblReorderSuccess.TabIndex = 27
        Me.lblReorderSuccess.Text = "Your order has been " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "successfully completed."
        Me.lblReorderSuccess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSelectedHeader
        '
        Me.lblSelectedHeader.AutoSize = True
        Me.lblSelectedHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectedHeader.Location = New System.Drawing.Point(610, 222)
        Me.lblSelectedHeader.Name = "lblSelectedHeader"
        Me.lblSelectedHeader.Size = New System.Drawing.Size(112, 20)
        Me.lblSelectedHeader.TabIndex = 28
        Me.lblSelectedHeader.Text = "Selected Item:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.lblProductQty)
        Me.Panel1.Controls.Add(Me.lblNameHeader)
        Me.Panel1.Controls.Add(Me.lblNameOutput)
        Me.Panel1.Controls.Add(Me.lblProductPriceOutput)
        Me.Panel1.Controls.Add(Me.lblProductQtyOutput)
        Me.Panel1.Controls.Add(Me.lblProductPrice)
        Me.Panel1.Location = New System.Drawing.Point(471, 245)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(384, 264)
        Me.Panel1.TabIndex = 29
        '
        'pnlPlaceReorder
        '
        Me.pnlPlaceReorder.BackColor = System.Drawing.Color.Red
        Me.pnlPlaceReorder.Controls.Add(Me.btnReorderInventory)
        Me.pnlPlaceReorder.Location = New System.Drawing.Point(890, 334)
        Me.pnlPlaceReorder.Name = "pnlPlaceReorder"
        Me.pnlPlaceReorder.Size = New System.Drawing.Size(273, 75)
        Me.pnlPlaceReorder.TabIndex = 31
        '
        'pnlReturnToMainMenu
        '
        Me.pnlReturnToMainMenu.BackColor = System.Drawing.Color.Red
        Me.pnlReturnToMainMenu.Controls.Add(Me.btnReturnToMain)
        Me.pnlReturnToMainMenu.Location = New System.Drawing.Point(890, 598)
        Me.pnlReturnToMainMenu.Name = "pnlReturnToMainMenu"
        Me.pnlReturnToMainMenu.Size = New System.Drawing.Size(273, 75)
        Me.pnlReturnToMainMenu.TabIndex = 32
        '
        'pnlPrintInventory
        '
        Me.pnlPrintInventory.BackColor = System.Drawing.Color.Red
        Me.pnlPrintInventory.Controls.Add(Me.btnPrintInventory)
        Me.pnlPrintInventory.Location = New System.Drawing.Point(890, 510)
        Me.pnlPrintInventory.Name = "pnlPrintInventory"
        Me.pnlPrintInventory.Size = New System.Drawing.Size(273, 75)
        Me.pnlPrintInventory.TabIndex = 33
        '
        'pnlRefresh
        '
        Me.pnlRefresh.BackColor = System.Drawing.Color.Red
        Me.pnlRefresh.Controls.Add(Me.btnRefresh)
        Me.pnlRefresh.Location = New System.Drawing.Point(890, 422)
        Me.pnlRefresh.Name = "pnlRefresh"
        Me.pnlRefresh.Size = New System.Drawing.Size(273, 75)
        Me.pnlRefresh.TabIndex = 34
        '
        'frmOrderInventory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(201, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1175, 685)
        Me.Controls.Add(Me.pnlRefresh)
        Me.Controls.Add(Me.pnlPrintInventory)
        Me.Controls.Add(Me.pnlReturnToMainMenu)
        Me.Controls.Add(Me.pnlPlaceReorder)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblSelectedHeader)
        Me.Controls.Add(Me.lblReorderSuccess)
        Me.Controls.Add(Me.dgvOrderInventory)
        Me.Controls.Add(Me.lblReorderQuantity)
        Me.Controls.Add(Me.txtReorderQuantity)
        Me.Controls.Add(Me.lblOrderInventory)
        Me.Controls.Add(Me.lblSubHeader)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.lblReorderInventoryHeader)
        Me.Controls.Add(Me.mnuReorderInventory)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuReorderInventory
        Me.Name = "frmOrderInventory"
        Me.Text = "Joy's Toys - Order Inventory"
        Me.mnuReorderInventory.ResumeLayout(False)
        Me.mnuReorderInventory.PerformLayout()
        CType(Me.dgvOrderInventory, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlPlaceReorder.ResumeLayout(False)
        Me.pnlReturnToMainMenu.ResumeLayout(False)
        Me.pnlPrintInventory.ResumeLayout(False)
        Me.pnlRefresh.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblSubHeader As Label
    Friend WithEvents lblHeader As Label
    Friend WithEvents lblReorderInventoryHeader As Label
    Friend WithEvents lblOrderInventory As Label
    Friend WithEvents btnReorderInventory As Button
    Friend WithEvents txtReorderQuantity As TextBox
    Friend WithEvents lblReorderQuantity As Label
    Friend WithEvents mnuReorderInventory As MenuStrip
    Friend WithEvents btnReturnToMain As Button
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HomepageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewCustomerOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewCustomerRequestsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents dgvOrderInventory As DataGridView
    Friend WithEvents btnRefresh As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents lblNameHeader As Label
    Friend WithEvents lblNameOutput As Label
    Friend WithEvents lblProductQty As Label
    Friend WithEvents lblProductQtyOutput As Label
    Friend WithEvents lblProductPrice As Label
    Friend WithEvents lblProductPriceOutput As Label
    Friend WithEvents lblReorderSuccess As Label
    Friend WithEvents lblSelectedHeader As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnPrintInventory As Button
    Friend WithEvents pnlPlaceReorder As Panel
    Friend WithEvents pnlReturnToMainMenu As Panel
    Friend WithEvents pnlPrintInventory As Panel
    Friend WithEvents pnlRefresh As Panel
End Class
