﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmViewRequests
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmViewRequests))
        Me.lblRequestHeader = New System.Windows.Forms.Label()
        Me.lblSubHeader = New System.Windows.Forms.Label()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.btnReturnToMain = New System.Windows.Forms.Button()
        Me.mnuCustomerRequests = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomepageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewCustomerOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrderNewInventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.dgvRequests = New System.Windows.Forms.DataGridView()
        Me.btnPrintRequests = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.pnlPrintRequests = New System.Windows.Forms.Panel()
        Me.pnlReturnToMainMenu = New System.Windows.Forms.Panel()
        Me.mnuCustomerRequests.SuspendLayout()
        CType(Me.dgvRequests, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlPrintRequests.SuspendLayout()
        Me.pnlReturnToMainMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblRequestHeader
        '
        Me.lblRequestHeader.AutoSize = True
        Me.lblRequestHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRequestHeader.Location = New System.Drawing.Point(237, 134)
        Me.lblRequestHeader.Name = "lblRequestHeader"
        Me.lblRequestHeader.Size = New System.Drawing.Size(326, 29)
        Me.lblRequestHeader.TabIndex = 2
        Me.lblRequestHeader.Text = "Online Customer Requests"
        '
        'lblSubHeader
        '
        Me.lblSubHeader.AutoSize = True
        Me.lblSubHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubHeader.Location = New System.Drawing.Point(226, 64)
        Me.lblSubHeader.Name = "lblSubHeader"
        Me.lblSubHeader.Size = New System.Drawing.Size(340, 24)
        Me.lblSubHeader.TabIndex = 7
        Me.lblSubHeader.Text = "Family owned and operated since 1945"
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.Red
        Me.lblHeader.Location = New System.Drawing.Point(131, 9)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(536, 55)
        Me.lblHeader.TabIndex = 6
        Me.lblHeader.Text = "Welcome to Joy's Toys"
        '
        'btnReturnToMain
        '
        Me.btnReturnToMain.BackColor = System.Drawing.Color.LightGray
        Me.btnReturnToMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturnToMain.ForeColor = System.Drawing.Color.Black
        Me.btnReturnToMain.Location = New System.Drawing.Point(3, 3)
        Me.btnReturnToMain.Name = "btnReturnToMain"
        Me.btnReturnToMain.Size = New System.Drawing.Size(238, 57)
        Me.btnReturnToMain.TabIndex = 25
        Me.btnReturnToMain.Text = "Return to Main Menu"
        Me.ToolTip1.SetToolTip(Me.btnReturnToMain, "Go Back to Main Menu Page")
        Me.btnReturnToMain.UseVisualStyleBackColor = False
        '
        'mnuCustomerRequests
        '
        Me.mnuCustomerRequests.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.mnuCustomerRequests.Location = New System.Drawing.Point(0, 0)
        Me.mnuCustomerRequests.Name = "mnuCustomerRequests"
        Me.mnuCustomerRequests.Size = New System.Drawing.Size(800, 24)
        Me.mnuCustomerRequests.TabIndex = 26
        Me.mnuCustomerRequests.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomepageToolStripMenuItem, Me.NewCustomerOrderToolStripMenuItem, Me.OrderNewInventoryToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'HomepageToolStripMenuItem
        '
        Me.HomepageToolStripMenuItem.Name = "HomepageToolStripMenuItem"
        Me.HomepageToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.HomepageToolStripMenuItem.Text = "&Main Menu"
        '
        'NewCustomerOrderToolStripMenuItem
        '
        Me.NewCustomerOrderToolStripMenuItem.Name = "NewCustomerOrderToolStripMenuItem"
        Me.NewCustomerOrderToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.NewCustomerOrderToolStripMenuItem.Text = "New Customer &Order"
        '
        'OrderNewInventoryToolStripMenuItem
        '
        Me.OrderNewInventoryToolStripMenuItem.Name = "OrderNewInventoryToolStripMenuItem"
        Me.OrderNewInventoryToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.OrderNewInventoryToolStripMenuItem.Text = "Order New &Inventory"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'dgvRequests
        '
        Me.dgvRequests.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvRequests.Location = New System.Drawing.Point(64, 184)
        Me.dgvRequests.Name = "dgvRequests"
        Me.dgvRequests.Size = New System.Drawing.Size(665, 306)
        Me.dgvRequests.TabIndex = 27
        '
        'btnPrintRequests
        '
        Me.btnPrintRequests.BackColor = System.Drawing.Color.LightGray
        Me.btnPrintRequests.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrintRequests.ForeColor = System.Drawing.Color.Black
        Me.btnPrintRequests.Location = New System.Drawing.Point(3, 3)
        Me.btnPrintRequests.Name = "btnPrintRequests"
        Me.btnPrintRequests.Size = New System.Drawing.Size(238, 57)
        Me.btnPrintRequests.TabIndex = 28
        Me.btnPrintRequests.Text = "Print Requests"
        Me.ToolTip1.SetToolTip(Me.btnPrintRequests, "Print List of Customer Requests")
        Me.btnPrintRequests.UseVisualStyleBackColor = False
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'pnlPrintRequests
        '
        Me.pnlPrintRequests.BackColor = System.Drawing.Color.Red
        Me.pnlPrintRequests.Controls.Add(Me.btnPrintRequests)
        Me.pnlPrintRequests.Location = New System.Drawing.Point(12, 516)
        Me.pnlPrintRequests.Name = "pnlPrintRequests"
        Me.pnlPrintRequests.Size = New System.Drawing.Size(245, 63)
        Me.pnlPrintRequests.TabIndex = 29
        '
        'pnlReturnToMainMenu
        '
        Me.pnlReturnToMainMenu.BackColor = System.Drawing.Color.Red
        Me.pnlReturnToMainMenu.Controls.Add(Me.btnReturnToMain)
        Me.pnlReturnToMainMenu.Location = New System.Drawing.Point(543, 516)
        Me.pnlReturnToMainMenu.Name = "pnlReturnToMainMenu"
        Me.pnlReturnToMainMenu.Size = New System.Drawing.Size(245, 63)
        Me.pnlReturnToMainMenu.TabIndex = 30
        '
        'frmViewRequests
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(201, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 591)
        Me.Controls.Add(Me.pnlReturnToMainMenu)
        Me.Controls.Add(Me.pnlPrintRequests)
        Me.Controls.Add(Me.dgvRequests)
        Me.Controls.Add(Me.lblSubHeader)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.lblRequestHeader)
        Me.Controls.Add(Me.mnuCustomerRequests)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuCustomerRequests
        Me.Name = "frmViewRequests"
        Me.Text = "Joy's Toys - View Requests"
        Me.mnuCustomerRequests.ResumeLayout(False)
        Me.mnuCustomerRequests.PerformLayout()
        CType(Me.dgvRequests, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlPrintRequests.ResumeLayout(False)
        Me.pnlReturnToMainMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblRequestHeader As Label
    Friend WithEvents lblSubHeader As Label
    Friend WithEvents lblHeader As Label
    Friend WithEvents btnReturnToMain As Button
    Friend WithEvents mnuCustomerRequests As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HomepageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewCustomerOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrderNewInventoryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents dgvRequests As DataGridView
    Friend WithEvents btnPrintRequests As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents pnlPrintRequests As Panel
    Friend WithEvents pnlReturnToMainMenu As Panel
End Class
