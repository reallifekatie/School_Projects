﻿Public Class frmMain

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim iExit As DialogResult

        iExit = MessageBox.Show("Done playing with toys?", "Joy's Toys", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If iExit = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub btnOrderInv_Click(sender As Object, e As EventArgs) Handles btnOrderInv.Click
        Dim frmOrderInventory As New frmOrderInventory
        Hide()
        frmOrderInventory.ShowDialog()

    End Sub

    Private Sub btnCustomerOrder_Click(sender As Object, e As EventArgs) Handles btnCustomerOrder.Click
        Dim frmCustomerOrder As New frmCustomerOrder
        Hide()
        frmCustomerOrder.ShowDialog()

    End Sub

    Private Sub btnRequests_Click(sender As Object, e As EventArgs) Handles btnRequests.Click
        Dim frmViewRequests As New frmViewRequests
        Hide()
        frmViewRequests.ShowDialog()

    End Sub


    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnCustomerOrder.Focus()

    End Sub
End Class
