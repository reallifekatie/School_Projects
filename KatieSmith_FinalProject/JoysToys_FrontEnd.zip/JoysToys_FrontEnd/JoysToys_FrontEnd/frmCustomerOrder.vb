﻿Imports MySql.Data.MySqlClient
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.Win32

Public Class frmCustomerOrder

    Dim sqlConn As New MySqlConnection
    Dim sqlCmd As New MySqlCommand
    Dim sqlRd As MySqlDataReader
    Dim sqlDt As New DataTable
    Dim DtA As New MySqlDataAdapter
    Dim sqlQuery As String

    Dim server As String = "localhost"
    Dim username As String = "root"
    Dim password As String = ""
    Dim database As String = "joys_toys"

    Dim strCartProdNameArray As New List(Of String)
    Dim intCartProdIDArray As New List(Of Int32)
    Dim decCartProdPriceArray As New List(Of Decimal)
    Dim intOrderQuantityArray As New List(Of Int32)
    Dim decCartProdTotalArray As New List(Of Decimal)

    Private bitmap As Bitmap

    Private Sub updateTable()
        dgvCustomerOrder.DataSource = Nothing

        sqlConn.ConnectionString = "server = " + server + ";" + "user id = " + username + ";" +
            "password = " + password + ";" + "database = " + database

        sqlConn.Open()
        sqlCmd.Connection = sqlConn
        sqlCmd.CommandText = "SELECT product_id, product_name, product_qty, product_price FROM joys_toys.inventory"

        sqlRd = sqlCmd.ExecuteReader
        sqlDt.Load(sqlRd)
        sqlRd.Close()
        sqlConn.Close()
        dgvCustomerOrder.DataSource = sqlDt

    End Sub

    Private Sub btnReturnToMain_Click(sender As Object, e As EventArgs) Handles btnReturnToMain.Click
        Dim frmMain As New frmMain
        Hide()
        frmMain.ShowDialog()

    End Sub

    Private Sub HomepageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomepageToolStripMenuItem.Click
        Dim frmMain As New frmMain
        Hide()
        frmMain.ShowDialog()
    End Sub

    Private Sub OrderNewInventoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderNewInventoryToolStripMenuItem.Click
        Dim frmOrderInventory As New frmOrderInventory
        Hide()
        frmOrderInventory.ShowDialog()
    End Sub

    Private Sub ViewCustomerRequestsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewCustomerRequestsToolStripMenuItem.Click
        Dim frmViewRequests As New frmViewRequests
        Hide()
        frmViewRequests.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim iExit As DialogResult

        iExit = MessageBox.Show("Done playing with toys?", "Joy's Toys", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If iExit = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub frmCustomerOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblProductIDOutput.Visible = False
        lblProductNameOutput.Visible = False
        lblProductPriceOutput.Visible = False
        lblProductQtyOutput.Visible = False
        lblCartTotalOutput.Visible = False

        txtOrderQuantity.Focus()
        updateTable()

    End Sub

    Private Sub btnRefreshInventory_Click(sender As Object, e As EventArgs) Handles btnRefreshInventory.Click
        updateTable()

    End Sub

    Private Sub dgvCustomerOrder_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvCustomerOrder.CellClick
        Try
            lblProductIDOutput.Text = dgvCustomerOrder.SelectedRows(0).Cells(0).Value.ToString
            lblProductNameOutput.Text = dgvCustomerOrder.SelectedRows(0).Cells(1).Value.ToString
            lblProductQtyOutput.Text = dgvCustomerOrder.SelectedRows(0).Cells(2).Value.ToString
            lblProductPriceOutput.Text = dgvCustomerOrder.SelectedRows(0).Cells(3).Value.ToString
            lblProductIDOutput.Visible = True
            lblProductNameOutput.Visible = True
            lblProductPriceOutput.Visible = True
            lblProductQtyOutput.Visible = True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnAddToCart_Click(sender As Object, e As EventArgs) Handles btnAddToCart.Click
        Dim arrayStringItem As String
        Dim arrayIntItem As Integer
        Dim arrayDecItem As Decimal
        Dim arrayDecTotal As Decimal
        Dim decItemTotal As Decimal
        Dim decCartTotal As Decimal
        Dim decCartSubtotal As Decimal

        decItemTotal = Convert.ToDecimal(txtOrderQuantity.Text) * Convert.ToDecimal(lblProductPriceOutput.Text)

        strCartProdNameArray.Add(lblProductNameOutput.Text)
        intCartProdIDArray.Add(lblProductIDOutput.Text)
        decCartProdPriceArray.Add(lblProductPriceOutput.Text)
        intOrderQuantityArray.Add(txtOrderQuantity.Text)
        decCartProdTotalArray.Add(decItemTotal)

        lstShoppingCartName.Items.Clear()
        lstShoppingCartQuantity.Items.Clear()
        lstShoppingCartPrice.Items.Clear()
        lstShoppingCartTotal.Items.Clear()
        lblCartTotalOutput.Text = ""

        For Each arrayStringItem In strCartProdNameArray
            lstShoppingCartName.Items.Add(arrayStringItem)
        Next
        For Each arrayDecItem In decCartProdPriceArray
            lstShoppingCartPrice.Items.Add(arrayDecItem)
        Next
        For Each arrayIntItem In intOrderQuantityArray
            lstShoppingCartQuantity.Items.Add(arrayIntItem)
        Next
        For Each arrayDecTotal In decCartProdTotalArray
            lstShoppingCartTotal.Items.Add(arrayDecTotal)
        Next
        For Each decCartTotal In decCartProdTotalArray
            decCartSubtotal += decItemTotal
            lblCartTotalOutput.Text = ""
            lblCartTotalOutput.Text = decCartSubtotal.ToString
            lblCartTotalOutput.Visible = True
        Next


        lblProductNameOutput.Visible = False
        lblProductIDOutput.Visible = False
        lblProductQtyOutput.Visible = False
        lblProductPriceOutput.Visible = False
        ''txtOrderQuantity.Text = ""

    End Sub

    Private Sub btnCheckout_Click(sender As Object, e As EventArgs) Handles btnCheckout.Click
        Dim decOrderTotal As Decimal
        Dim intOldQty As Integer
        Dim intOrderQty As Integer
        Dim intNewQty As Integer

        sqlConn.ConnectionString = "server = " + server + ";" + "user id = " + username + ";" +
            "password = " + password + ";" + "database = " + database
        sqlConn.Open()

        sqlCmd.Connection = sqlConn

        decOrderTotal = Convert.ToDecimal(lblProductIDOutput.Text) * Convert.ToDecimal(lblProductPriceOutput.Text)

        intOldQty = Convert.ToInt32(lblProductQtyOutput.Text)

        Try
            intOrderQty = Convert.ToInt32(txtOrderQuantity.Text)
        Catch ex As Exception
            intOrderQty = 1
        End Try

        intNewQty = intOldQty - intOrderQty

        With sqlCmd
            .CommandText = "INSERT INTO joys_toys.orders (product_id, order_total, order_date) VALUES (@product_id1, @order_total, @order_date)"
            .CommandType = CommandType.Text
            .Parameters.AddWithValue("@product_id1", lblProductIDOutput.Text)
            .Parameters.AddWithValue("@order_total", decOrderTotal)
            .Parameters.AddWithValue("@order_date", Date.Now)
        End With

        With sqlCmd
            .CommandText = "INSERT INTO joys_toys.order_content (product_id, quantity, product_price) VALUES (@product_id2, @quantity, @product_price)"
            .CommandType = CommandType.Text
            .Parameters.AddWithValue("@product_id2", lblProductIDOutput.Text)
            .Parameters.AddWithValue("@quantity", txtOrderQuantity.Text)
            .Parameters.AddWithValue("@product_price", lblProductPriceOutput.Text)
        End With

        With sqlCmd
            .CommandText = "UPDATE joys_toys.inventory SET product_qty = @newQuantity WHERE product_id = @product_id3"
            .CommandType = CommandType.Text
            .Parameters.AddWithValue("@newQuantity", intNewQty)
            .Parameters.AddWithValue("@product_id3", lblProductIDOutput.Text)
        End With

        With sqlCmd
            .CommandText = "INSERT INTO joys_toys.customers (first_name, last_name, addr1, addr2, city, state, zip, phone, email) VALUES (@fname, @lname,
                @addr1, @addr2, @city, @state, @zip, @phone, @email)"
            .CommandType = CommandType.Text
            .Parameters.AddWithValue("@fname", txtFirstName.Text)
            .Parameters.AddWithValue("@lname", txtLastName.Text)
            .Parameters.AddWithValue("@addr1", txtAddr1.Text)
            .Parameters.AddWithValue("@addr2", txtAddr2.Text)
            .Parameters.AddWithValue("@city", txtCity.Text)
            .Parameters.AddWithValue("@state", txtState.Text)
            .Parameters.AddWithValue("@zip", txtZipCode.Text)
            .Parameters.AddWithValue("@phone", txtPhone.Text)
            .Parameters.AddWithValue("@email", txtEmail.Text)
        End With

        txtFirstName.Clear()
        txtLastName.Clear()
        txtAddr1.Clear()
        txtAddr2.Clear()
        txtCity.Clear()
        txtState.Clear()
        txtZipCode.Clear()
        txtPhone.Clear()
        txtEmail.Clear()
        lstShoppingCartName.Items.Clear()
        lstShoppingCartPrice.Items.Clear()
        lstShoppingCartQuantity.Items.Clear()
        lstShoppingCartTotal.Items.Clear()
        txtOrderQuantity.Text = ""

        sqlCmd.ExecuteNonQuery()
        sqlConn.Close()
        updateTable()

    End Sub
End Class