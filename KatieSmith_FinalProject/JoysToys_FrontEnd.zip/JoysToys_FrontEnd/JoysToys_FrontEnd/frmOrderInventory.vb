﻿Imports MySql.Data.MySqlClient
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.Win32

Public Class frmOrderInventory

    Dim sqlConn As New MySqlConnection
    Dim sqlCmd As New MySqlCommand
    Dim sqlOldQty As New MySqlCommand

    Dim sqlRd As MySqlDataReader
    Dim sqlDt As New DataTable
    Dim DtA As New MySqlDataAdapter
    Dim sqlQuery As String

    Dim server As String = "localhost"
    Dim username As String = "root"
    Dim password As String = ""
    Dim database As String = "joys_toys"

    Private bitmap As Bitmap

    Private Sub updateTable()
        sqlConn.ConnectionString = "server = " + server + ";" + "user id = " + username + ";" +
            "password = " + password + ";" + "database = " + database

        sqlConn.Open()
        sqlCmd.Connection = sqlConn
        sqlCmd.CommandText = "SELECT product_name, product_qty, product_price FROM joys_toys.inventory"

        sqlRd = sqlCmd.ExecuteReader
        sqlDt.Load(sqlRd)
        sqlRd.Close()
        sqlConn.Close()
        dgvOrderInventory.DataSource = sqlDt
    End Sub

    Private Sub btnReturnToMain_Click(sender As Object, e As EventArgs) Handles btnReturnToMain.Click
        Dim frmMain As New frmMain

        Hide()
        frmMain.ShowDialog()
    End Sub

    Private Sub HomepageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomepageToolStripMenuItem.Click
        Dim frmMain As New frmMain
        Hide()
        frmMain.ShowDialog()
    End Sub

    Private Sub NewCustomerOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewCustomerOrderToolStripMenuItem.Click
        Dim frmCustomerOrder As New frmCustomerOrder
        Hide()
        frmCustomerOrder.ShowDialog()
    End Sub

    Private Sub ViewCustomerRequestsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewCustomerRequestsToolStripMenuItem.Click
        Dim frmViewRequests As New frmViewRequests
        Hide()
        frmViewRequests.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim iExit As DialogResult

        iExit = MessageBox.Show("Done playing with toys?", "Joy's Toys", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If iExit = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub frmOrderInventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtReorderQuantity.Text = ""
        lblNameOutput.Text = ""
        lblProductQtyOutput.Text = ""
        lblProductPriceOutput.Text = ""
        lblReorderSuccess.Visible = False
        updateTable()

    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Dim dgvOrderInventory As New DataGridView
        txtReorderQuantity.Text = ""
        lblNameOutput.Text = ""
        lblProductQtyOutput.Text = ""
        lblProductPriceOutput.Text = ""
        lblReorderSuccess.Visible = False
        updateTable()

    End Sub

    Private Sub btnReorderInventory_Click(sender As Object, e As EventArgs) Handles btnReorderInventory.Click
        Dim currentQty As New Integer
        Dim newQty As New Integer
        Dim reorderQty As New Integer
        Dim prodName As String
        Dim intInvalidNum As New Integer

        sqlCmd.CommandText = "SELECT * FROM joys_toys.inventory"

        prodName = dgvOrderInventory.SelectedRows(0).Cells(0).Value
        currentQty = dgvOrderInventory.SelectedRows(0).Cells(1).Value
        newQty = Convert.ToInt32(txtReorderQuantity.Text)
        reorderQty = currentQty + newQty

        If (txtReorderQuantity.Text > 0) Then
            sqlConn.ConnectionString = "server = " + server + ";" + "user id = " + username + ";" +
            "password = " + password + ";" + "database = " + database
            sqlConn.Open()
            sqlCmd.Connection = sqlConn

            With sqlCmd
                .CommandText = "UPDATE joys_toys.inventory SET product_qty = @reorderQty WHERE product_name = @productName"
                .CommandType = CommandType.Text
                .Parameters.AddWithValue("@reorderQty", reorderQty)
                .Parameters.AddWithValue("@productName", prodName)

                sqlCmd.ExecuteNonQuery()
                sqlConn.Close()
                txtReorderQuantity.Text = ""
                lblNameOutput.Text = ""
                lblProductQtyOutput.Text = ""
                lblProductPriceOutput.Text = ""
                lblReorderSuccess.Visible = True
                dgvOrderInventory.Dispose()
            End With
        Else
            intInvalidNum = MessageBox.Show("Please enter a valid, whole number.", "Joy's Toys", MessageBoxButtons.OKCancel, MessageBoxIcon.Error)
            txtReorderQuantity.Text = ""
        End If

    End Sub

    Private Sub dgvOrderInventory_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvOrderInventory.CellClick
        Try
            lblNameOutput.Text = dgvOrderInventory.SelectedRows(0).Cells(0).Value.ToString
            lblProductQtyOutput.Text = dgvOrderInventory.SelectedRows(0).Cells(1).Value.ToString
            lblProductPriceOutput.Text = dgvOrderInventory.SelectedRows(0).Cells(2).Value.ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnPrintInventory_Click(sender As Object, e As EventArgs) Handles btnPrintInventory.Click
        Dim height As Integer = dgvOrderInventory.Height
        dgvOrderInventory.Height = dgvOrderInventory.RowCount * dgvOrderInventory.RowTemplate.Height
        bitmap = New Bitmap(Me.dgvOrderInventory.Width, Me.dgvOrderInventory.Height)
        dgvOrderInventory.DrawToBitmap(bitmap, New Rectangle(0, 0, Me.dgvOrderInventory.Width, Me.dgvOrderInventory.Height))
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
        PrintPreviewDialog1.ShowDialog()
        dgvOrderInventory.Height = height
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawImage(bitmap, 0, 0)
        Dim recP As RectangleF = e.PageSettings.PrintableArea
        If Me.dgvOrderInventory.Height - recP.Height > 0 Then e.HasMorePages = True
    End Sub
End Class