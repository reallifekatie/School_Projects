﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomerOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCustomerOrder))
        Me.lblSubHeader = New System.Windows.Forms.Label()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.lblCustomerOrder = New System.Windows.Forms.Label()
        Me.lblSelectInventory = New System.Windows.Forms.Label()
        Me.btnRefreshInventory = New System.Windows.Forms.Button()
        Me.lblOrderQuantity = New System.Windows.Forms.Label()
        Me.txtOrderQuantity = New System.Windows.Forms.TextBox()
        Me.btnAddToCart = New System.Windows.Forms.Button()
        Me.btnCheckout = New System.Windows.Forms.Button()
        Me.lblCart = New System.Windows.Forms.Label()
        Me.mnuCustomerOrder = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomepageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrderNewInventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewCustomerRequestsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnReturnToMain = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.dgvCustomerOrder = New System.Windows.Forms.DataGridView()
        Me.lblSelectedItem = New System.Windows.Forms.Label()
        Me.lblProductQty = New System.Windows.Forms.Label()
        Me.lblProductPrice = New System.Windows.Forms.Label()
        Me.lblProductNameOutput = New System.Windows.Forms.Label()
        Me.lblProductQtyOutput = New System.Windows.Forms.Label()
        Me.lblProductPriceOutput = New System.Windows.Forms.Label()
        Me.pnlSelectedItem = New System.Windows.Forms.Panel()
        Me.lblProductIDOutput = New System.Windows.Forms.Label()
        Me.lblProductID = New System.Windows.Forms.Label()
        Me.lstShoppingCartName = New System.Windows.Forms.ListBox()
        Me.lblCartTotal = New System.Windows.Forms.Label()
        Me.lblCartTotalOutput = New System.Windows.Forms.Label()
        Me.lstShoppingCartQuantity = New System.Windows.Forms.ListBox()
        Me.lstShoppingCartPrice = New System.Windows.Forms.ListBox()
        Me.lstShoppingCartTotal = New System.Windows.Forms.ListBox()
        Me.lblCartName = New System.Windows.Forms.Label()
        Me.lblItemQty = New System.Windows.Forms.Label()
        Me.lblItemPrice = New System.Windows.Forms.Label()
        Me.lblItemTotal = New System.Windows.Forms.Label()
        Me.pnlRefreshInventory = New System.Windows.Forms.Panel()
        Me.pnlCheckout = New System.Windows.Forms.Panel()
        Me.pnlAddToCart = New System.Windows.Forms.Panel()
        Me.pnlReturnToMainMenu = New System.Windows.Forms.Panel()
        Me.pnlCustomerInfo = New System.Windows.Forms.Panel()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblAddr1 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.txtAddr1 = New System.Windows.Forms.TextBox()
        Me.txtZipCode = New System.Windows.Forms.TextBox()
        Me.txtAddr2 = New System.Windows.Forms.TextBox()
        Me.lblZipCode = New System.Windows.Forms.Label()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.lblAddr2 = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.lblState = New System.Windows.Forms.Label()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblCustomerInfoHeader = New System.Windows.Forms.Label()
        Me.mnuCustomerOrder.SuspendLayout()
        CType(Me.dgvCustomerOrder, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSelectedItem.SuspendLayout()
        Me.pnlRefreshInventory.SuspendLayout()
        Me.pnlCheckout.SuspendLayout()
        Me.pnlAddToCart.SuspendLayout()
        Me.pnlReturnToMainMenu.SuspendLayout()
        Me.pnlCustomerInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblSubHeader
        '
        Me.lblSubHeader.AutoSize = True
        Me.lblSubHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubHeader.Location = New System.Drawing.Point(650, 79)
        Me.lblSubHeader.Name = "lblSubHeader"
        Me.lblSubHeader.Size = New System.Drawing.Size(340, 24)
        Me.lblSubHeader.TabIndex = 13
        Me.lblSubHeader.Text = "Family owned and operated since 1945"
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.Red
        Me.lblHeader.Location = New System.Drawing.Point(552, 24)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(536, 55)
        Me.lblHeader.TabIndex = 12
        Me.lblHeader.Text = "Welcome to Joy's Toys"
        '
        'lblCustomerOrder
        '
        Me.lblCustomerOrder.AutoSize = True
        Me.lblCustomerOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerOrder.Location = New System.Drawing.Point(720, 116)
        Me.lblCustomerOrder.Name = "lblCustomerOrder"
        Me.lblCustomerOrder.Size = New System.Drawing.Size(200, 29)
        Me.lblCustomerOrder.TabIndex = 11
        Me.lblCustomerOrder.Text = "Customer Order"
        '
        'lblSelectInventory
        '
        Me.lblSelectInventory.AutoSize = True
        Me.lblSelectInventory.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectInventory.Location = New System.Drawing.Point(140, 166)
        Me.lblSelectInventory.Name = "lblSelectInventory"
        Me.lblSelectInventory.Size = New System.Drawing.Size(174, 20)
        Me.lblSelectInventory.TabIndex = 15
        Me.lblSelectInventory.Text = "1) Select Item to Order:"
        '
        'btnRefreshInventory
        '
        Me.btnRefreshInventory.BackColor = System.Drawing.Color.LightGray
        Me.btnRefreshInventory.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefreshInventory.ForeColor = System.Drawing.Color.Black
        Me.btnRefreshInventory.Location = New System.Drawing.Point(3, 3)
        Me.btnRefreshInventory.Name = "btnRefreshInventory"
        Me.btnRefreshInventory.Size = New System.Drawing.Size(147, 86)
        Me.btnRefreshInventory.TabIndex = 16
        Me.btnRefreshInventory.Text = "Refresh Inventory"
        Me.ToolTip1.SetToolTip(Me.btnRefreshInventory, "Refresh Inventory List")
        Me.btnRefreshInventory.UseVisualStyleBackColor = False
        '
        'lblOrderQuantity
        '
        Me.lblOrderQuantity.AutoSize = True
        Me.lblOrderQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrderQuantity.Location = New System.Drawing.Point(464, 452)
        Me.lblOrderQuantity.Name = "lblOrderQuantity"
        Me.lblOrderQuantity.Size = New System.Drawing.Size(134, 20)
        Me.lblOrderQuantity.TabIndex = 17
        Me.lblOrderQuantity.Text = "2) Order Quantity:"
        '
        'txtOrderQuantity
        '
        Me.txtOrderQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOrderQuantity.Location = New System.Drawing.Point(499, 487)
        Me.txtOrderQuantity.Name = "txtOrderQuantity"
        Me.txtOrderQuantity.Size = New System.Drawing.Size(74, 26)
        Me.txtOrderQuantity.TabIndex = 1
        Me.txtOrderQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ToolTip1.SetToolTip(Me.txtOrderQuantity, "# of Items to Add to Cart")
        '
        'btnAddToCart
        '
        Me.btnAddToCart.BackColor = System.Drawing.Color.LightGray
        Me.btnAddToCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddToCart.ForeColor = System.Drawing.Color.Black
        Me.btnAddToCart.Location = New System.Drawing.Point(3, 3)
        Me.btnAddToCart.Name = "btnAddToCart"
        Me.btnAddToCart.Size = New System.Drawing.Size(147, 86)
        Me.btnAddToCart.TabIndex = 19
        Me.btnAddToCart.Text = "3) Add to Cart"
        Me.ToolTip1.SetToolTip(Me.btnAddToCart, "Add Item to Cart")
        Me.btnAddToCart.UseVisualStyleBackColor = False
        '
        'btnCheckout
        '
        Me.btnCheckout.BackColor = System.Drawing.Color.LightGray
        Me.btnCheckout.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckout.ForeColor = System.Drawing.Color.Black
        Me.btnCheckout.Location = New System.Drawing.Point(3, 3)
        Me.btnCheckout.Name = "btnCheckout"
        Me.btnCheckout.Size = New System.Drawing.Size(275, 86)
        Me.btnCheckout.TabIndex = 11
        Me.btnCheckout.Text = "5) Complete Order"
        Me.ToolTip1.SetToolTip(Me.btnCheckout, "Process Customer Order")
        Me.btnCheckout.UseVisualStyleBackColor = False
        '
        'lblCart
        '
        Me.lblCart.AutoSize = True
        Me.lblCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCart.Location = New System.Drawing.Point(997, 153)
        Me.lblCart.Name = "lblCart"
        Me.lblCart.Size = New System.Drawing.Size(115, 20)
        Me.lblCart.TabIndex = 21
        Me.lblCart.Text = "Shopping Cart:"
        '
        'mnuCustomerOrder
        '
        Me.mnuCustomerOrder.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.mnuCustomerOrder.Location = New System.Drawing.Point(0, 0)
        Me.mnuCustomerOrder.Name = "mnuCustomerOrder"
        Me.mnuCustomerOrder.Size = New System.Drawing.Size(1640, 24)
        Me.mnuCustomerOrder.TabIndex = 23
        Me.mnuCustomerOrder.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomepageToolStripMenuItem, Me.OrderNewInventoryToolStripMenuItem, Me.ViewCustomerRequestsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'HomepageToolStripMenuItem
        '
        Me.HomepageToolStripMenuItem.Name = "HomepageToolStripMenuItem"
        Me.HomepageToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.HomepageToolStripMenuItem.Text = "&Main Menu"
        '
        'OrderNewInventoryToolStripMenuItem
        '
        Me.OrderNewInventoryToolStripMenuItem.Name = "OrderNewInventoryToolStripMenuItem"
        Me.OrderNewInventoryToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.OrderNewInventoryToolStripMenuItem.Text = "Order New &Inventory"
        '
        'ViewCustomerRequestsToolStripMenuItem
        '
        Me.ViewCustomerRequestsToolStripMenuItem.Name = "ViewCustomerRequestsToolStripMenuItem"
        Me.ViewCustomerRequestsToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.ViewCustomerRequestsToolStripMenuItem.Text = "View Customer &Requests"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'btnReturnToMain
        '
        Me.btnReturnToMain.BackColor = System.Drawing.Color.LightGray
        Me.btnReturnToMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturnToMain.ForeColor = System.Drawing.Color.Black
        Me.btnReturnToMain.Location = New System.Drawing.Point(4, 3)
        Me.btnReturnToMain.Name = "btnReturnToMain"
        Me.btnReturnToMain.Size = New System.Drawing.Size(275, 86)
        Me.btnReturnToMain.TabIndex = 24
        Me.btnReturnToMain.Text = "Return to Main Menu"
        Me.ToolTip1.SetToolTip(Me.btnReturnToMain, "Go Back to Main Menu Page")
        Me.btnReturnToMain.UseVisualStyleBackColor = False
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'dgvCustomerOrder
        '
        Me.dgvCustomerOrder.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvCustomerOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCustomerOrder.Location = New System.Drawing.Point(7, 189)
        Me.dgvCustomerOrder.Name = "dgvCustomerOrder"
        Me.dgvCustomerOrder.Size = New System.Drawing.Size(431, 560)
        Me.dgvCustomerOrder.TabIndex = 25
        '
        'lblSelectedItem
        '
        Me.lblSelectedItem.AutoSize = True
        Me.lblSelectedItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectedItem.Location = New System.Drawing.Point(123, 2)
        Me.lblSelectedItem.Name = "lblSelectedItem"
        Me.lblSelectedItem.Size = New System.Drawing.Size(112, 20)
        Me.lblSelectedItem.TabIndex = 26
        Me.lblSelectedItem.Text = "Selected Item:"
        '
        'lblProductQty
        '
        Me.lblProductQty.AutoSize = True
        Me.lblProductQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductQty.Location = New System.Drawing.Point(13, 87)
        Me.lblProductQty.Name = "lblProductQty"
        Me.lblProductQty.Size = New System.Drawing.Size(72, 20)
        Me.lblProductQty.TabIndex = 28
        Me.lblProductQty.Text = "In Stock:"
        '
        'lblProductPrice
        '
        Me.lblProductPrice.AutoSize = True
        Me.lblProductPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductPrice.Location = New System.Drawing.Point(13, 141)
        Me.lblProductPrice.Name = "lblProductPrice"
        Me.lblProductPrice.Size = New System.Drawing.Size(107, 20)
        Me.lblProductPrice.TabIndex = 29
        Me.lblProductPrice.Text = "Product Price:"
        '
        'lblProductNameOutput
        '
        Me.lblProductNameOutput.AutoSize = True
        Me.lblProductNameOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductNameOutput.Location = New System.Drawing.Point(13, 42)
        Me.lblProductNameOutput.Name = "lblProductNameOutput"
        Me.lblProductNameOutput.Size = New System.Drawing.Size(17, 20)
        Me.lblProductNameOutput.TabIndex = 30
        Me.lblProductNameOutput.Text = "x"
        '
        'lblProductQtyOutput
        '
        Me.lblProductQtyOutput.AutoSize = True
        Me.lblProductQtyOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductQtyOutput.Location = New System.Drawing.Point(145, 87)
        Me.lblProductQtyOutput.Name = "lblProductQtyOutput"
        Me.lblProductQtyOutput.Size = New System.Drawing.Size(16, 20)
        Me.lblProductQtyOutput.TabIndex = 31
        Me.lblProductQtyOutput.Text = "x"
        '
        'lblProductPriceOutput
        '
        Me.lblProductPriceOutput.AutoSize = True
        Me.lblProductPriceOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductPriceOutput.Location = New System.Drawing.Point(145, 141)
        Me.lblProductPriceOutput.Name = "lblProductPriceOutput"
        Me.lblProductPriceOutput.Size = New System.Drawing.Size(16, 20)
        Me.lblProductPriceOutput.TabIndex = 32
        Me.lblProductPriceOutput.Text = "x"
        '
        'pnlSelectedItem
        '
        Me.pnlSelectedItem.BackColor = System.Drawing.SystemColors.Control
        Me.pnlSelectedItem.Controls.Add(Me.lblProductIDOutput)
        Me.pnlSelectedItem.Controls.Add(Me.lblProductID)
        Me.pnlSelectedItem.Controls.Add(Me.lblSelectedItem)
        Me.pnlSelectedItem.Controls.Add(Me.lblProductNameOutput)
        Me.pnlSelectedItem.Controls.Add(Me.lblProductPriceOutput)
        Me.pnlSelectedItem.Controls.Add(Me.lblProductQty)
        Me.pnlSelectedItem.Controls.Add(Me.lblProductPrice)
        Me.pnlSelectedItem.Controls.Add(Me.lblProductQtyOutput)
        Me.pnlSelectedItem.Location = New System.Drawing.Point(465, 189)
        Me.pnlSelectedItem.Name = "pnlSelectedItem"
        Me.pnlSelectedItem.Size = New System.Drawing.Size(362, 234)
        Me.pnlSelectedItem.TabIndex = 34
        '
        'lblProductIDOutput
        '
        Me.lblProductIDOutput.AutoSize = True
        Me.lblProductIDOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductIDOutput.Location = New System.Drawing.Point(145, 186)
        Me.lblProductIDOutput.Name = "lblProductIDOutput"
        Me.lblProductIDOutput.Size = New System.Drawing.Size(16, 20)
        Me.lblProductIDOutput.TabIndex = 34
        Me.lblProductIDOutput.Text = "x"
        '
        'lblProductID
        '
        Me.lblProductID.AutoSize = True
        Me.lblProductID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProductID.Location = New System.Drawing.Point(13, 186)
        Me.lblProductID.Name = "lblProductID"
        Me.lblProductID.Size = New System.Drawing.Size(58, 20)
        Me.lblProductID.TabIndex = 33
        Me.lblProductID.Text = "Item #:"
        '
        'lstShoppingCartName
        '
        Me.lstShoppingCartName.BackColor = System.Drawing.SystemColors.Control
        Me.lstShoppingCartName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstShoppingCartName.FormattingEnabled = True
        Me.lstShoppingCartName.ItemHeight = 16
        Me.lstShoppingCartName.Location = New System.Drawing.Point(879, 191)
        Me.lstShoppingCartName.Name = "lstShoppingCartName"
        Me.lstShoppingCartName.Size = New System.Drawing.Size(149, 436)
        Me.lstShoppingCartName.TabIndex = 0
        '
        'lblCartTotal
        '
        Me.lblCartTotal.AutoSize = True
        Me.lblCartTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCartTotal.Location = New System.Drawing.Point(1066, 630)
        Me.lblCartTotal.Name = "lblCartTotal"
        Me.lblCartTotal.Size = New System.Drawing.Size(82, 20)
        Me.lblCartTotal.TabIndex = 35
        Me.lblCartTotal.Text = "Cart Total:"
        '
        'lblCartTotalOutput
        '
        Me.lblCartTotalOutput.AutoSize = True
        Me.lblCartTotalOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCartTotalOutput.Location = New System.Drawing.Point(1165, 630)
        Me.lblCartTotalOutput.Name = "lblCartTotalOutput"
        Me.lblCartTotalOutput.Size = New System.Drawing.Size(16, 20)
        Me.lblCartTotalOutput.TabIndex = 36
        Me.lblCartTotalOutput.Text = "x"
        '
        'lstShoppingCartQuantity
        '
        Me.lstShoppingCartQuantity.BackColor = System.Drawing.SystemColors.Control
        Me.lstShoppingCartQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstShoppingCartQuantity.FormattingEnabled = True
        Me.lstShoppingCartQuantity.ItemHeight = 16
        Me.lstShoppingCartQuantity.Location = New System.Drawing.Point(1034, 191)
        Me.lstShoppingCartQuantity.Name = "lstShoppingCartQuantity"
        Me.lstShoppingCartQuantity.Size = New System.Drawing.Size(43, 436)
        Me.lstShoppingCartQuantity.TabIndex = 38
        '
        'lstShoppingCartPrice
        '
        Me.lstShoppingCartPrice.BackColor = System.Drawing.SystemColors.Control
        Me.lstShoppingCartPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstShoppingCartPrice.FormattingEnabled = True
        Me.lstShoppingCartPrice.ItemHeight = 16
        Me.lstShoppingCartPrice.Location = New System.Drawing.Point(1083, 191)
        Me.lstShoppingCartPrice.Name = "lstShoppingCartPrice"
        Me.lstShoppingCartPrice.Size = New System.Drawing.Size(65, 436)
        Me.lstShoppingCartPrice.TabIndex = 39
        '
        'lstShoppingCartTotal
        '
        Me.lstShoppingCartTotal.BackColor = System.Drawing.SystemColors.Control
        Me.lstShoppingCartTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstShoppingCartTotal.FormattingEnabled = True
        Me.lstShoppingCartTotal.ItemHeight = 16
        Me.lstShoppingCartTotal.Location = New System.Drawing.Point(1156, 191)
        Me.lstShoppingCartTotal.Name = "lstShoppingCartTotal"
        Me.lstShoppingCartTotal.Size = New System.Drawing.Size(58, 436)
        Me.lstShoppingCartTotal.TabIndex = 40
        '
        'lblCartName
        '
        Me.lblCartName.AutoSize = True
        Me.lblCartName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCartName.Location = New System.Drawing.Point(885, 175)
        Me.lblCartName.Name = "lblCartName"
        Me.lblCartName.Size = New System.Drawing.Size(44, 16)
        Me.lblCartName.TabIndex = 41
        Me.lblCartName.Text = "Name"
        '
        'lblItemQty
        '
        Me.lblItemQty.AutoSize = True
        Me.lblItemQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemQty.Location = New System.Drawing.Point(1042, 173)
        Me.lblItemQty.Name = "lblItemQty"
        Me.lblItemQty.Size = New System.Drawing.Size(27, 16)
        Me.lblItemQty.TabIndex = 42
        Me.lblItemQty.Text = "Qty"
        '
        'lblItemPrice
        '
        Me.lblItemPrice.AutoSize = True
        Me.lblItemPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemPrice.Location = New System.Drawing.Point(1098, 175)
        Me.lblItemPrice.Name = "lblItemPrice"
        Me.lblItemPrice.Size = New System.Drawing.Size(38, 16)
        Me.lblItemPrice.TabIndex = 43
        Me.lblItemPrice.Text = "Price"
        '
        'lblItemTotal
        '
        Me.lblItemTotal.AutoSize = True
        Me.lblItemTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemTotal.Location = New System.Drawing.Point(1166, 175)
        Me.lblItemTotal.Name = "lblItemTotal"
        Me.lblItemTotal.Size = New System.Drawing.Size(38, 16)
        Me.lblItemTotal.TabIndex = 44
        Me.lblItemTotal.Text = "Total"
        '
        'pnlRefreshInventory
        '
        Me.pnlRefreshInventory.BackColor = System.Drawing.Color.Red
        Me.pnlRefreshInventory.Controls.Add(Me.btnRefreshInventory)
        Me.pnlRefreshInventory.Location = New System.Drawing.Point(465, 651)
        Me.pnlRefreshInventory.Name = "pnlRefreshInventory"
        Me.pnlRefreshInventory.Size = New System.Drawing.Size(154, 92)
        Me.pnlRefreshInventory.TabIndex = 45
        '
        'pnlCheckout
        '
        Me.pnlCheckout.BackColor = System.Drawing.Color.Red
        Me.pnlCheckout.Controls.Add(Me.btnCheckout)
        Me.pnlCheckout.Location = New System.Drawing.Point(1346, 538)
        Me.pnlCheckout.Name = "pnlCheckout"
        Me.pnlCheckout.Size = New System.Drawing.Size(282, 92)
        Me.pnlCheckout.TabIndex = 46
        '
        'pnlAddToCart
        '
        Me.pnlAddToCart.BackColor = System.Drawing.Color.Red
        Me.pnlAddToCart.Controls.Add(Me.btnAddToCart)
        Me.pnlAddToCart.Location = New System.Drawing.Point(673, 452)
        Me.pnlAddToCart.Name = "pnlAddToCart"
        Me.pnlAddToCart.Size = New System.Drawing.Size(154, 92)
        Me.pnlAddToCart.TabIndex = 47
        '
        'pnlReturnToMainMenu
        '
        Me.pnlReturnToMainMenu.BackColor = System.Drawing.Color.Red
        Me.pnlReturnToMainMenu.Controls.Add(Me.btnReturnToMain)
        Me.pnlReturnToMainMenu.Location = New System.Drawing.Point(1346, 651)
        Me.pnlReturnToMainMenu.Name = "pnlReturnToMainMenu"
        Me.pnlReturnToMainMenu.Size = New System.Drawing.Size(282, 92)
        Me.pnlReturnToMainMenu.TabIndex = 48
        '
        'pnlCustomerInfo
        '
        Me.pnlCustomerInfo.BackColor = System.Drawing.SystemColors.Control
        Me.pnlCustomerInfo.Controls.Add(Me.lblFirstName)
        Me.pnlCustomerInfo.Controls.Add(Me.txtFirstName)
        Me.pnlCustomerInfo.Controls.Add(Me.lblLastName)
        Me.pnlCustomerInfo.Controls.Add(Me.txtLastName)
        Me.pnlCustomerInfo.Controls.Add(Me.lblEmail)
        Me.pnlCustomerInfo.Controls.Add(Me.txtEmail)
        Me.pnlCustomerInfo.Controls.Add(Me.lblAddr1)
        Me.pnlCustomerInfo.Controls.Add(Me.txtPhone)
        Me.pnlCustomerInfo.Controls.Add(Me.lblPhone)
        Me.pnlCustomerInfo.Controls.Add(Me.txtAddr1)
        Me.pnlCustomerInfo.Controls.Add(Me.txtZipCode)
        Me.pnlCustomerInfo.Controls.Add(Me.txtAddr2)
        Me.pnlCustomerInfo.Controls.Add(Me.lblZipCode)
        Me.pnlCustomerInfo.Controls.Add(Me.txtState)
        Me.pnlCustomerInfo.Controls.Add(Me.lblAddr2)
        Me.pnlCustomerInfo.Controls.Add(Me.txtCity)
        Me.pnlCustomerInfo.Controls.Add(Me.lblState)
        Me.pnlCustomerInfo.Controls.Add(Me.lblCity)
        Me.pnlCustomerInfo.Location = New System.Drawing.Point(1232, 189)
        Me.pnlCustomerInfo.Name = "pnlCustomerInfo"
        Me.pnlCustomerInfo.Size = New System.Drawing.Size(393, 295)
        Me.pnlCustomerInfo.TabIndex = 50
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstName.Location = New System.Drawing.Point(12, 25)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(75, 16)
        Me.lblFirstName.TabIndex = 20
        Me.lblFirstName.Text = "First Name:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(115, 22)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(267, 22)
        Me.txtFirstName.TabIndex = 2
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastName.Location = New System.Drawing.Point(12, 53)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(75, 16)
        Me.lblLastName.TabIndex = 19
        Me.lblLastName.Text = "Last Name:"
        '
        'txtLastName
        '
        Me.txtLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastName.Location = New System.Drawing.Point(115, 50)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(267, 22)
        Me.txtLastName.TabIndex = 3
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(12, 249)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(98, 16)
        Me.lblEmail.TabIndex = 29
        Me.lblEmail.Text = "Email Address:"
        '
        'txtEmail
        '
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.Location = New System.Drawing.Point(115, 246)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(267, 22)
        Me.txtEmail.TabIndex = 10
        '
        'lblAddr1
        '
        Me.lblAddr1.AutoSize = True
        Me.lblAddr1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddr1.Location = New System.Drawing.Point(12, 81)
        Me.lblAddr1.Name = "lblAddr1"
        Me.lblAddr1.Size = New System.Drawing.Size(99, 16)
        Me.lblAddr1.TabIndex = 18
        Me.lblAddr1.Text = "Address Line 1:"
        '
        'txtPhone
        '
        Me.txtPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.Location = New System.Drawing.Point(115, 218)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(267, 22)
        Me.txtPhone.TabIndex = 9
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone.Location = New System.Drawing.Point(12, 221)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(100, 16)
        Me.lblPhone.TabIndex = 28
        Me.lblPhone.Text = "Phone Number:"
        '
        'txtAddr1
        '
        Me.txtAddr1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddr1.Location = New System.Drawing.Point(115, 78)
        Me.txtAddr1.Name = "txtAddr1"
        Me.txtAddr1.Size = New System.Drawing.Size(267, 22)
        Me.txtAddr1.TabIndex = 4
        '
        'txtZipCode
        '
        Me.txtZipCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZipCode.Location = New System.Drawing.Point(115, 190)
        Me.txtZipCode.Name = "txtZipCode"
        Me.txtZipCode.Size = New System.Drawing.Size(267, 22)
        Me.txtZipCode.TabIndex = 8
        '
        'txtAddr2
        '
        Me.txtAddr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddr2.Location = New System.Drawing.Point(115, 106)
        Me.txtAddr2.Name = "txtAddr2"
        Me.txtAddr2.Size = New System.Drawing.Size(267, 22)
        Me.txtAddr2.TabIndex = 5
        '
        'lblZipCode
        '
        Me.lblZipCode.AutoSize = True
        Me.lblZipCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZipCode.Location = New System.Drawing.Point(12, 193)
        Me.lblZipCode.Name = "lblZipCode"
        Me.lblZipCode.Size = New System.Drawing.Size(65, 16)
        Me.lblZipCode.TabIndex = 27
        Me.lblZipCode.Text = "Zip Code:"
        '
        'txtState
        '
        Me.txtState.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtState.Location = New System.Drawing.Point(115, 162)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(267, 22)
        Me.txtState.TabIndex = 7
        '
        'lblAddr2
        '
        Me.lblAddr2.AutoSize = True
        Me.lblAddr2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddr2.Location = New System.Drawing.Point(12, 109)
        Me.lblAddr2.Name = "lblAddr2"
        Me.lblAddr2.Size = New System.Drawing.Size(99, 16)
        Me.lblAddr2.TabIndex = 17
        Me.lblAddr2.Text = "Address Line 2:"
        '
        'txtCity
        '
        Me.txtCity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCity.Location = New System.Drawing.Point(115, 134)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(267, 22)
        Me.txtCity.TabIndex = 6
        '
        'lblState
        '
        Me.lblState.AutoSize = True
        Me.lblState.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblState.Location = New System.Drawing.Point(12, 165)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(41, 16)
        Me.lblState.TabIndex = 26
        Me.lblState.Text = "State:"
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCity.Location = New System.Drawing.Point(12, 137)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(32, 16)
        Me.lblCity.TabIndex = 16
        Me.lblCity.Text = "City:"
        '
        'lblCustomerInfoHeader
        '
        Me.lblCustomerInfoHeader.AutoSize = True
        Me.lblCustomerInfoHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerInfoHeader.Location = New System.Drawing.Point(1343, 166)
        Me.lblCustomerInfoHeader.Name = "lblCustomerInfoHeader"
        Me.lblCustomerInfoHeader.Size = New System.Drawing.Size(185, 20)
        Me.lblCustomerInfoHeader.TabIndex = 34
        Me.lblCustomerInfoHeader.Text = "4) Customer Information:"
        '
        'frmCustomerOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(201, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1640, 755)
        Me.Controls.Add(Me.lblCustomerInfoHeader)
        Me.Controls.Add(Me.pnlCustomerInfo)
        Me.Controls.Add(Me.pnlReturnToMainMenu)
        Me.Controls.Add(Me.pnlAddToCart)
        Me.Controls.Add(Me.pnlCheckout)
        Me.Controls.Add(Me.pnlRefreshInventory)
        Me.Controls.Add(Me.lblItemTotal)
        Me.Controls.Add(Me.lblItemPrice)
        Me.Controls.Add(Me.lblItemQty)
        Me.Controls.Add(Me.lblCartName)
        Me.Controls.Add(Me.lstShoppingCartTotal)
        Me.Controls.Add(Me.lstShoppingCartPrice)
        Me.Controls.Add(Me.lstShoppingCartQuantity)
        Me.Controls.Add(Me.lblCartTotalOutput)
        Me.Controls.Add(Me.lblCartTotal)
        Me.Controls.Add(Me.lstShoppingCartName)
        Me.Controls.Add(Me.pnlSelectedItem)
        Me.Controls.Add(Me.dgvCustomerOrder)
        Me.Controls.Add(Me.lblCart)
        Me.Controls.Add(Me.txtOrderQuantity)
        Me.Controls.Add(Me.lblOrderQuantity)
        Me.Controls.Add(Me.lblSelectInventory)
        Me.Controls.Add(Me.lblSubHeader)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.lblCustomerOrder)
        Me.Controls.Add(Me.mnuCustomerOrder)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuCustomerOrder
        Me.Name = "frmCustomerOrder"
        Me.Text = "Joy's Toys - Customer Order"
        Me.mnuCustomerOrder.ResumeLayout(False)
        Me.mnuCustomerOrder.PerformLayout()
        CType(Me.dgvCustomerOrder, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSelectedItem.ResumeLayout(False)
        Me.pnlSelectedItem.PerformLayout()
        Me.pnlRefreshInventory.ResumeLayout(False)
        Me.pnlCheckout.ResumeLayout(False)
        Me.pnlAddToCart.ResumeLayout(False)
        Me.pnlReturnToMainMenu.ResumeLayout(False)
        Me.pnlCustomerInfo.ResumeLayout(False)
        Me.pnlCustomerInfo.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblSubHeader As Label
    Friend WithEvents lblHeader As Label
    Friend WithEvents lblCustomerOrder As Label
    Friend WithEvents lblSelectInventory As Label
    Friend WithEvents btnRefreshInventory As Button
    Friend WithEvents lblOrderQuantity As Label
    Friend WithEvents txtOrderQuantity As TextBox
    Friend WithEvents btnAddToCart As Button
    Friend WithEvents btnCheckout As Button
    Friend WithEvents lblCart As Label
    Friend WithEvents mnuCustomerOrder As MenuStrip
    Friend WithEvents btnReturnToMain As Button
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HomepageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrderNewInventoryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewCustomerRequestsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents dgvCustomerOrder As DataGridView
    Friend WithEvents lblSelectedItem As Label
    Friend WithEvents lblProductQty As Label
    Friend WithEvents lblProductPrice As Label
    Friend WithEvents lblProductNameOutput As Label
    Friend WithEvents lblProductQtyOutput As Label
    Friend WithEvents lblProductPriceOutput As Label
    Friend WithEvents pnlSelectedItem As Panel
    Friend WithEvents lblProductIDOutput As Label
    Friend WithEvents lblProductID As Label
    Friend WithEvents lstShoppingCartName As ListBox
    Friend WithEvents lblCartTotal As Label
    Friend WithEvents lblCartTotalOutput As Label
    Friend WithEvents lstShoppingCartQuantity As ListBox
    Friend WithEvents lstShoppingCartPrice As ListBox
    Friend WithEvents lstShoppingCartTotal As ListBox
    Friend WithEvents lblCartName As Label
    Friend WithEvents lblItemQty As Label
    Friend WithEvents lblItemPrice As Label
    Friend WithEvents lblItemTotal As Label
    Friend WithEvents pnlRefreshInventory As Panel
    Friend WithEvents pnlCheckout As Panel
    Friend WithEvents pnlAddToCart As Panel
    Friend WithEvents pnlReturnToMainMenu As Panel
    Friend WithEvents pnlCustomerInfo As Panel
    Friend WithEvents lblCustomerInfoHeader As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents lblLastName As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents lblAddr1 As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents lblPhone As Label
    Friend WithEvents txtAddr1 As TextBox
    Friend WithEvents txtZipCode As TextBox
    Friend WithEvents txtAddr2 As TextBox
    Friend WithEvents lblZipCode As Label
    Friend WithEvents txtState As TextBox
    Friend WithEvents lblAddr2 As Label
    Friend WithEvents txtCity As TextBox
    Friend WithEvents lblState As Label
    Friend WithEvents lblCity As Label
End Class
