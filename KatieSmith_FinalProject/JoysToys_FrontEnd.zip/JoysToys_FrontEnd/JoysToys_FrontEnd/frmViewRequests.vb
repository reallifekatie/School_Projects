﻿Imports MySql.Data.MySqlClient
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.Win32

Public Class frmViewRequests

    Dim sqlConn As New MySqlConnection
    Dim sqlCmd As New MySqlCommand
    Dim sqlRd As MySqlDataReader
    Dim sqlDt As New DataTable
    Dim DtA As New MySqlDataAdapter
    Dim sqlQuery As String

    Dim server As String = "localhost"
    Dim username As String = "root"
    Dim password As String = ""
    Dim database As String = "joys_toys"

    Private bitmap As Bitmap

    Private Sub updateTable()
        sqlConn.ConnectionString = "server = " + server + ";" + "user id = " + username + ";" +
            "password = " + password + ";" + "database = " + database

        sqlConn.Open()
        sqlCmd.Connection = sqlConn
        sqlCmd.CommandText = "SELECT * FROM joys_toys.requests"

        sqlRd = sqlCmd.ExecuteReader
        sqlDt.Load(sqlRd)
        sqlRd.Close()
        sqlConn.Close()
        dgvRequests.DataSource = sqlDt

    End Sub

    Private Sub btnReturnToMain_Click(sender As Object, e As EventArgs) Handles btnReturnToMain.Click
        Dim frmMain As New frmMain
        Hide()
        frmMain.ShowDialog()
    End Sub

    Private Sub HomepageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomepageToolStripMenuItem.Click
        Dim frmMain As New frmMain
        Hide()
        frmMain.ShowDialog()
    End Sub

    Private Sub NewCustomerOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewCustomerOrderToolStripMenuItem.Click
        Dim frmCustomerOrder As New frmCustomerOrder
        Hide()
        frmCustomerOrder.ShowDialog()
    End Sub

    Private Sub OrderNewInventoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderNewInventoryToolStripMenuItem.Click
        Dim frmOrderInventory As New frmOrderInventory
        Hide()
        frmOrderInventory.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim iExit As DialogResult

        iExit = MessageBox.Show("Done playing with toys?", "Joy's Toys", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If iExit = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub frmViewRequests_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        updateTable()

    End Sub

    Private Sub btnPrintRequests_Click(sender As Object, e As EventArgs) Handles btnPrintRequests.Click
        Dim height As Integer = dgvRequests.Height
        dgvRequests.Height = dgvRequests.RowCount * dgvRequests.RowTemplate.Height
        bitmap = New Bitmap(Me.dgvRequests.Width, Me.dgvRequests.Height)
        dgvRequests.DrawToBitmap(bitmap, New Rectangle(0, 0, Me.dgvRequests.Width, Me.dgvRequests.Height))
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
        PrintPreviewDialog1.ShowDialog()
        dgvRequests.Height = height
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawImage(bitmap, 0, 0)
        Dim recP As RectangleF = e.PageSettings.PrintableArea

        If Me.dgvRequests.Height - recP.Height > 0 Then e.HasMorePages = True
    End Sub
End Class