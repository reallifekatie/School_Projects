<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   

</head>
   
<?php include("./includes/header.php"); ?>
    
<body>
    
<div class="w3-content">
    <br>
    <h1 class="w3-center" style="margin-bottom:16px">Toy Store</h1>
    <h5 class="w3-center">Family owned and operated since 1945.</h5>
    <br>
</div>

    <br><br>
<div>  
    
<?php
  
    $sql = "SELECT * FROM joys_toys.inventory";
    $result = $dbc->query($sql);
    $newColumn = 0;
    if ($result->num_rows > 0) {

        while($row = $result->fetch_assoc()) {
             if ($newColumn = 0 || $newColumn = 3 || $newColumn = 5 || $newColumn = 7) {
                 echo '<table>';
              }
                    echo '<tr>';
                        echo "<td style='width:40%'>";
                        echo "<img src='{$row['product_image']}' >";
                        echo '</td>';
            
                        echo "<td style='width:60%'>";
                        echo '<form action="toysAdded.php" method="POST">';
                        echo "<input type='hidden' name='product_id' value='{$row['product_id']}' >";
                        echo "<input type='hidden'  name='product_name' value='{$row['product_name']}'>";
                        echo '<h5><input type="submit" class="w3-button w3-red" value="Add to Cart"></h5>';
                        echo '</form>';

                        echo "<h5 style='color:black'><b>{$row['product_name']}</b></h5>";
                        echo "<p style='color:black'>{$row['product_descr']}</p>";
                        echo "<h5 style='color:black'><b>$ {$row['product_price']}</b></h5>";
            
                        echo '</td>';
            
                    echo '</tr>';

             if ($newColumn = 0 || $newColumn = 3 || $newColumn = 5 || $newColumn = 7) {
               echo '</table>';

             }
            $newColumn +=1;
        }
    } else {
        echo "0 results";
    }
echo "<br><br><br><hr>";

?>   
</div>
    <script type="text/javascript">
    document.getElementById("viewCartButton").onclick = function () {
        location.href = "./toysCart.php"
    }
    </script>

<?php include("./includes/footer.php"); ?>

</body>
</html>




