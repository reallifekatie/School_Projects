<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   
 
</head>

<?php include("./includes/header.php"); ?>
    
<body>

  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <div class="w3-container w3-xlarge">

    <p class="w3-right">
      <a href="toysCart.php"><button id="viewCartButton" class="fa fa-shopping-cart w3-margin-right"> Cart </button></a>

    </p>
  </div>

  <div class="w3-container w3-center" id="toys">
      
      <?php
  
    // Get passed product id and assign it to a variable
    if (isset( $_POST['product_id'])) {
        $id = $_POST['product_id'];
    } 
    
    // Retrieve selective item data from 'inventory' database table
    $q = "SELECT * FROM joys_toys.inventory WHERE product_id = $id ";
    $r = mysqli_query( $dbc, $q );
    if (mysqli_num_rows( $r ) == 1) {
        
        $row = mysqli_fetch_array( $r,  MYSQLI_ASSOC );
        
        // Check if cart already contains one of this product id
        if (isset( $_SESSION['cart'][$id])) {
            // Add one more of this product
            $_SESSION['cart'][$id]['product_qty']++;
            echo '<h5>Another '.$row["product_name"].' has been added to your cart.</h5><br>';
        }
        else {
            // Or add one of this product to the cart
            $_SESSION['cart'][$id]= array ('product_qty' => 1, 'product_price' => $row['product_price']);
            echo '<h5>A '.$row["product_name"].' has been added to your cart.</h5><br>';
        }
    }
      echo '<h5><a href="store.php">Toy Store</a></h5>';
?>
    </div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-32"></div>

<?php include("./includes/footer.php"); ?>

</body>
</html>