<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   
 
</head>
    
<?php include("./includes/header.php"); ?>
     
<body>

<div>
  <div class="w3-content">
      <br>
      <h1 class="w3-center" style="margin-bottom:16px">Family owned and operated since 1945.</h1>

      <h5>Joy's Toys harkens back to a simpler time... childhood.  And not just any childhood, but one that doesn't involve screens and batteries.  Here at Joy's Toys, we specialize in analog and manipulative toys.  What are analog and manipulative toys?</h5>
      <h5>Think about the toys you played with as a kid that didn't require batteries or plug into the wall, nor did they have a screen.  Those are analog toys.</h5>
      <h5>Now think back to the toys that helped you learn.  Whether it was learning motor skills, learning colors and shapes, or state and world capitals.  Those are manipulative toys.</h5>
      <h4 class="w3-center">THAT is what we do very well.</h4>
      
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-32"></div>

<?php include("./includes/footer.php"); ?>

</body>
</html>

