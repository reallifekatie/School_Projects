<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   
 
</head>

<?php include("./includes/header.php"); ?>
    
<body>

<div>
  <div class="w3-center">
      <br>
      <h1 class="w3-center" style="margin-bottom:16px">Location & Hours</h1>

      <h3><u>Location:</u></h3>
      <h5>601 E. Main St</h5>
      <h5>Jamestown, NC 27282</h5>
      <hr>
      <h3><u>Phone:</u></h3>
      <h5>(336) 867-5309</h5>
      <hr>
      <h3><u>Hours of Operation:</u></h3>
      <h5>Sunday: Closed</h5>
      <h5>Monday: Closed</h5>
      <h5>Tuesday: 9am - 6pm</h5>
      <h5>Wednesday: 9am - 6pm</h5>
      <h5>Thursday: 9am - 6pm</h5>
      <h5>Friday: 9am - 6pm</h5>
      <h5>Saturday: 9am - 6pm</h5>

      <br>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-32"></div>

<?php include("./includes/footer.php"); ?>

</body>
</html>

