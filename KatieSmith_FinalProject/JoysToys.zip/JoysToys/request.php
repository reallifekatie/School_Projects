<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   
 
</head>

<?php include("./includes/header.php"); ?>
    
<body>

<div class="w3-center">
 <?php
            // if statement to create actions for when the user clicks the Submit button
        if (isset($_POST['submit'])) {
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $email = $_POST['email'];
            $request = $_POST['request'];
            
            // sql statement variable to insert records into contact table
            $sqlInsert = "INSERT INTO requests (first_name, last_name, request_email, request) VALUES ('$fname', '$lname', '$email', '$request')";
            
            // if statement to confirm the new record was saved to the table
            if ($dbc->query($sqlInsert) === TRUE) {
                echo "<br><h3><p>Your request has been submitted.</p> <p>We will email you if we are able to get the item you requested in-stock.</p> <p>Thank you!</p></h3>";
            } else {
                echo "Error: " . $sqlInsert . "<br>" . $dbc->error;
            }
            echo "<br><hr>";
        }
        ?>
</div>  
        <div>
          <div class="w3-content">
            <br>
            <h1 class="w3-center" style="margin-bottom:16px">Request Form</h1>
            <h5>Looking for something specific?</h5>
            <h5>If you are looking for an item that we don't carry in our store, fill out the request from below and we will try to find it for you.</h5>
            <h5>No promises. But we will give it our best shot!</h5><br>
              
            <form action="" method="post">
                <h3>First Name:  <input type="text" name="fname" size="35"></h3>
                <h3>Last Name:  <input type="text" name="lname" size="35"></h3>
                <h3>Email Address:  <input type="text" name="email" size="50"></h3>

                <h3><input class="w3-input w3-padding-16 w3-border" type="text" placeholder="What are you looking for?" name="request"></h3>
    
                <h3><button class="w3-button w3-red w3-block" name="submit" type="submit">Submit Request Form</button></h3>
                <br><br>
            </form>
          </div>
        </div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-32"></div>

<?php include("./includes/footer.php"); ?>

</body>
</html>

