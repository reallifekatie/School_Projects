<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   
 
</head>

<?php include("./includes/header.php"); ?>
    
<body>

<div>
  <div class="w3-content">
      <br>
      <h1 class="w3-center" style="margin-bottom:16px">About Us</h1>
        <h5>Joy's Toys specializes in stocking and selling analog and manipulative toys.  We also carry puzzles, puppets, and classic games, like chess, checkers, and various card games.</h5>
        <h5>In 1945, after returning home from WWII, Jim Johnson was ready to start a family.  After the birth of their daughter Joy, Jim decided to open a toy store in town so that his daughter would always have toys to play with.</h5>
        <h5>In 1983, Jim decided to step aside and allow Joy to take over the reigns of the family business that bore her name.</h5>
        <h5>Having no kids of her own, Joy lives vicariously through making other people's children happy.  She is often heard saying that her favorite sound in the world is the laughter of children.</h5>
      <br>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-32"></div>

<?php include("./includes/footer.php"); ?>

</body>
</html>

