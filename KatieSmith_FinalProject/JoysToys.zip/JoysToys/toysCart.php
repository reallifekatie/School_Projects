<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   
 
</head>

<?php include("./includes/header.php"); ?>
    
<body>

<div>
  <div class="w3-content">
      <br>
      <h1 class="w3-center" style="margin-bottom:16px">Toy Cart</h1>
      
      <?php 
      // DISPLAY SHOPPING CART PAGE
      // Access session
      
      // Set page title and display header section
      $page_title = 'Cart';
      
      
      // Check if form has been submitted for update
      if ($_SERVER['REQUEST_METHOD'] == 'POST') {
          // Update changed quantity field values
              foreach ($_POST['product_qty'] as $product_id => $product_qty) {
                  // Ensure values are integers
                  $id = (int) $product_id;
                  $qty = (int) $product_qty;
                  
                  // Change quantity or delete if zero
                  if ($qty == 0) {
                      unset ($_SESSION['cart'][$id]);
                  }
                  elseif ($qty > 0) {
                      $_SESSION['cart'][$id]['product_qty'] = $qty;
                  }
              }
      }
      
      $total = 0;
      
      // Display the cart if not empty
      if (!empty($_SESSION['cart'])) {
          
          // Retrieve all items in the cart from the 'shop' database table
          $q = "SELECT * FROM joys_toys.inventory WHERE product_id IN (";
          foreach ($_SESSION['cart'] as $id => $value) {
               $q .= $id . ',';
          }
          $q = substr($q, 0, -1) . ') ORDER BY product_id ASC';
          $r = mysqli_query ($dbc, $q);
          
          // Display body section with a form and a table
          echo '<form action="toysCart.php" method="post"><table><tr><th colspan="5">Items in Your Cart</th></tr><tr>';
          while ($row = mysqli_fetch_array ($r, MYSQLI_ASSOC)) {
              // Calculate sub-totals and grand total
              $subtotal = $_SESSION['cart'][$row['product_id']]['product_qty'] * $_SESSION['cart'][$row['product_id']]['product_price'];
              $total += $subtotal;
              
              // Display the rows
              echo "<tr> <td>{$row['product_name']}</td> <td>{$row['product_descr']}</td> <td><input type=\"text\" size=\"3\" name=\"product_qty[{$row['product_id']}]\" value=\" {$_SESSION['cart'][$row['product_id']]['product_qty']} \"></td> <td>@ {$row['product_price']} = </td> <td>".number_format ($subtotal, 2)."</td></tr>";
          }
          
          mysqli_close($dbc);
          
          // Display the total
          echo ' <tr><td colspan="5" style="text-align:right">Total = '.number_format($total, 2).'</td></tr></table> <br> <input type="submit" name="submit" class="w3-button w3-red" value="Update My Cart"></form>';          
      }
      else {
          echo '<p>Your cart is currently empty.</p>';
      }
      
      // navigation links
      echo '<h5><a href="./store.php">Toy Store</a> | <a href="toysCheckout.php?total='.$total.'">Checkout</a></h5>';
      
?>
      <br>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-32"></div>

<?php include("./includes/footer.php"); ?>

</body>
</html>

