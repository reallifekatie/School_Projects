<!DOCTYPE html>
<html lang="en">
<head>
<title>Joy's Toys</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<link rel="stylesheet" href="./css/sitecss.css">   
 
</head>

<?php include("./includes/header.php"); ?>
    
<body>

<div>
  <div class="w3-content">
      <br>
      <h1 class="w3-center" style="margin-bottom:16px">Checkout</h1>    
      
      <?php
        
      if (isset($_GET['total']) && ( $_GET['total'] > 0) && (!empty($_SESSION['cart']))) {
              
          $q = "INSERT INTO joys_toys.orders (product_id, order_total, order_date) VALUES (product_id, ".$_GET['total'].", NOW() )";
          $r = mysqli_query ($dbc, $q);
          
          $order_id = mysqli_insert_id($dbc);
          
          $q = "SELECT * FROM joys_toys.inventory WHERE product_id IN (";
          foreach ($_SESSION['cart'] as $id => $value) {
              $q .= $id . ',';
          }
          
          $q = substr($q, 0, -1) . ') ORDER BY product_id ASC';
          $r = mysqli_query ($dbc, $q);
          
          // Store order contents in 'order_contents' database table
          while ($row = mysqli_fetch_array ($r, MYSQLI_ASSOC)) {
              $query = "INSERT INTO joys_toys.order_contents (order_id, product_id, quantity, product_price) VALUES ($order_id, ".$row['product_id'].",".$_SESSION['cart'][$row['product_id']]['product_qty'].",".$_SESSION['cart'][$row['product_id']]['product_price'].")";
              $result = mysqli_query($dbc, $query);
          }
          
          mysqli_close($dbc);
          
          // Display order number
          echo "<p>Thanks for your order.  Your Order Number is #".$order_id."</p>";
          
          // Remove cart items
          $_SESSION['cart'] = NULL;
      }

      else {
          echo '<p>There are no items in your cart.</p>';
      }
      
      echo '<p><a href="store.php">Toy Store</a></p>';
      
      ?>

      <br>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-32"></div>

<?php include("./includes/footer.php"); ?>

</body>
</html>

