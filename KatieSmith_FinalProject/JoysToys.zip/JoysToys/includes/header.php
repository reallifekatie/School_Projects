<?php 
    include("./includes/connect_db.php");  
    session_start();
?> 

<div class="w3-top">
  <div class="w3-bar w3-red w3-card w3-left-align w3-large">
          <button id="viewCartButton" class="fa fa-shopping-cart w3-right w3-xxlarge"> Cart </button>
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-red" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
     
    <a href="joystoys.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Home</a>
    <a href="store.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Toy Store</a>
    <a href="request.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Request Form</a>
    <a href="about.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">About Us</a>
    <a href="location_hours.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">Location & Hours</a>
  </div>

</div>

<header class="w3-container w3-red w3-center" style="padding:10px 16px">
    
    <div class="w3-right" style="width:100%">
        <br>

        <h1 class="w3-margin w3-center w3-jumbo">Joy's Toys</h1>
  <h2>Toy Shop</h2>
</div>
    
    <script type="text/javascript">
        document.getElementById("viewCartButton").onclick = function () {
            location.href = "./toysCart.php";
        };
    </script>

</header>
