<footer class="w3-container w3-padding-64 w3-center w3-opacity">  

 <p>Powered by <a href="https://smartfundamentals.godaddysites.com/" target="_blank">Smart Fundamentals, Inc.</a></p>
</footer>

